import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Plane, Calendar, Loader2 } from "lucide-react";
import { externalSupabase } from "@/integrations/external-supabase";
import { useAirportsByIcaos, useAircraftTypesByIds } from "@/hooks/useClientSearch";
import type { Airport } from "@/integrations/external-supabase/types";
import { formatAirportShort } from "./AirportCombobox";
import { getCategorySeatRange } from "@/lib/aircraft-utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { LeadCaptureDialog, type LeadCaptureContext } from "./LeadCaptureDialog";
import { supabase as internalSupabase } from "@/integrations/supabase/client";

const EXTERNAL_STORAGE_BASE =
  "https://zhjkexhurxafsurnsetw.supabase.co/storage/v1/object/public/aircraft-type-images/";

function getImageUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  return EXTERNAL_STORAGE_BASE + path;
}

function AircraftThumbnail({
  path,
  interiorPath,
  className,
}: {
  path: string | null | undefined;
  interiorPath?: string | null;
  className?: string;
}) {
  const [exteriorErrored, setExteriorErrored] = useState(false);
  const [interiorErrored, setInteriorErrored] = useState(false);
  const [activeSlot, setActiveSlot] = useState<"exterior" | "interior">("exterior");

  const extUrl = getImageUrl(path ?? null);
  const intUrl = getImageUrl(interiorPath ?? null);
  const hasToggle = !!extUrl && !exteriorErrored && !!intUrl && !interiorErrored;

  const handleClick = () => {
    if (hasToggle) setActiveSlot((s) => (s === "exterior" ? "interior" : "exterior"));
  };

  const showExt = extUrl && !exteriorErrored;
  const showInt = intUrl && !interiorErrored;

  return (
    <div
      className={`relative shrink-0 overflow-hidden rounded bg-muted/40 ${className ?? ""} ${hasToggle ? "cursor-pointer" : ""}`}
      onClick={handleClick}
    >
      {showExt && (
        <img
          src={extUrl}
          alt="Aircraft exterior"
          loading="lazy"
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-200 ease-in-out ${activeSlot === "exterior" ? "opacity-100" : "opacity-0"}`}
          onError={() => setExteriorErrored(true)}
        />
      )}
      {showInt && (
        <img
          src={intUrl}
          alt="Aircraft interior"
          loading="lazy"
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-200 ease-in-out ${activeSlot === "interior" ? "opacity-100" : "opacity-0"}`}
          onError={() => setInteriorErrored(true)}
        />
      )}
      {!showExt && !showInt && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Plane className="h-4 w-4 text-muted-foreground/25" />
        </div>
      )}
      {hasToggle && (
        <div className="absolute bottom-1 right-1 flex gap-1 pointer-events-none">
          <span className={`block h-1.5 w-1.5 rounded-full transition-colors duration-200 ${activeSlot === "exterior" ? "bg-white" : "bg-white/40"}`} />
          <span className={`block h-1.5 w-1.5 rounded-full transition-colors duration-200 ${activeSlot === "interior" ? "bg-white" : "bg-white/40"}`} />
        </div>
      )}
    </div>
  );
}

function parseDateOnly(dateStr: string): Date {
  const [year, month, day] = dateStr.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function formatDateRange(start: string, end: string): string {
  const startDate = parseDateOnly(start);
  const endDate = parseDateOnly(end);
  const startFormatted = format(startDate, "EEE MMM d");
  const endFormatted = format(endDate, "EEE MMM d");
  if (startFormatted === endFormatted) return startFormatted;
  return `${startFormatted} – ${endFormatted}`;
}

function formatCategory(category: string | null): string {
  if (!category) return "";
  return category.
  split("_").
  map((word) => word.charAt(0).toUpperCase() + word.slice(1)).
  join(" ");
}

function titleCase(str: string): string {
  return str.
  split(" ").
  map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).
  join(" ");
}

function formatLocationDisplay(
icao: string | null,
locationType: string | null,
corridor: string | null,
locationRaw: string | null,
airportsMap: Record<string, Airport>,
isLoading: boolean)
: React.ReactNode {
  if (locationType === "airport" && icao) {
    if (isLoading) return <Skeleton className="h-4 w-24 inline-block" />;
    const airport = airportsMap[icao];
    if (airport) return <span>{formatAirportShort(airport)}</span>;
    return <span className="font-mono text-xs">{icao}</span>;
  }
  if (locationRaw) return <span>{locationRaw}</span>;
  if (corridor) return <span>{titleCase(corridor)}</span>;
  if (icao) {
    if (isLoading) return <Skeleton className="h-4 w-24 inline-block" />;
    const airport = airportsMap[icao];
    if (airport) return <span>{formatAirportShort(airport)}</span>;
    return <span className="font-mono text-xs">{icao}</span>;
  }
  return <span className="text-muted-foreground">Unknown</span>;
}


const FALLBACK_PAIRS: Array<[string, string]> = [
  ["TORONTO_AREA", "FLORIDA"],
  ["NORTHEAST", "FLORIDA"],
  ["ENGLAND", "MEDITERRANEAN"],
  ["EASTERN_US", "WESTERN_US"],
];

type ConfigPair = { corridor_a: string; corridor_b: string; weight: number };

async function fetchFeaturedConfig(): Promise<{ totalCount: number; pairs: ConfigPair[] }> {
  try {
    const [settingsRes, pairsRes] = await Promise.all([
      internalSupabase.from("featured_settings").select("total_count").maybeSingle(),
      internalSupabase
        .from("featured_corridor_pairs")
        .select("corridor_a, corridor_b, weight, is_active, sort_order")
        .eq("is_active", true)
        .order("sort_order"),
    ]);

    const totalCount = settingsRes.data?.total_count ?? 15;
    const pairs = ((pairsRes.data as any[]) ?? []).map((p) => ({
      corridor_a: p.corridor_a,
      corridor_b: p.corridor_b,
      weight: Number(p.weight) || 0,
    }));

    if (pairs.length === 0) {
      const eq = 100 / FALLBACK_PAIRS.length;
      return {
        totalCount,
        pairs: FALLBACK_PAIRS.map(([a, b]) => ({ corridor_a: a, corridor_b: b, weight: eq })),
      };
    }
    return { totalCount, pairs };
  } catch {
    const eq = 100 / FALLBACK_PAIRS.length;
    return {
      totalCount: 15,
      pairs: FALLBACK_PAIRS.map(([a, b]) => ({ corridor_a: a, corridor_b: b, weight: eq })),
    };
  }
}

/** Weighted random sampling without replacement: pick from per-pair pools by weight, earliest-date first within each pool. */
function weightedSample<T>(pools: T[][], weights: number[], count: number): T[] {
  const picked: T[] = [];
  const queues = pools.map((p) => [...p]);

  while (picked.length < count) {
    const total = weights.reduce((s, w, i) => s + (queues[i].length > 0 ? w : 0), 0);
    if (total <= 0) break;
    let r = Math.random() * total;
    let chosen = -1;
    for (let i = 0; i < weights.length; i++) {
      if (queues[i].length === 0) continue;
      r -= weights[i];
      if (r <= 0) {
        chosen = i;
        break;
      }
    }
    if (chosen < 0) chosen = queues.findIndex((q) => q.length > 0);
    if (chosen < 0) break;
    picked.push(queues[chosen].shift()!);
  }
  return picked;
}

function useCorridorEmptyLegs() {
  return useQuery({
    queryKey: ["featured-empty-legs-config"],
    queryFn: async () => {
      const { totalCount, pairs } = await fetchFeaturedConfig();
      if (pairs.length === 0) return [];

      const rpcParams = {
        p_origin_anchor_type: "area",
        p_dest_anchor_type: "area",
        p_status: "active",
        p_date_start: null,
        p_date_end: null,
      };

      const POOL_CAP = 30;
      const perPairPools = await Promise.all(
        pairs.map(async (pair) => {
          const [resAB, resBA] = await Promise.all([
            externalSupabase.rpc("search_empty_legs_expand_v1" as never, {
              ...rpcParams,
              p_origin_anchor_value: pair.corridor_a,
              p_dest_anchor_value: pair.corridor_b,
              p_limit: POOL_CAP,
            } as never),
            externalSupabase.rpc("search_empty_legs_expand_v1" as never, {
              ...rpcParams,
              p_origin_anchor_value: pair.corridor_b,
              p_dest_anchor_value: pair.corridor_a,
              p_limit: POOL_CAP,
            } as never),
          ]);
          const merged = [
            ...(((resAB as any).data as any[]) ?? []),
            ...(((resBA as any).data as any[]) ?? []),
          ];
          const seen = new Set<string>();
          return merged
            .filter((l) => {
              if (seen.has(l.id)) return false;
              seen.add(l.id);
              return true;
            })
            .sort((a, b) => a.departure_date_start.localeCompare(b.departure_date_start))
            .slice(0, POOL_CAP);
        })
      );

      // Cross-pair dedupe (a leg may appear in multiple pair searches)
      const seenGlobal = new Set<string>();
      const dedupedPools = perPairPools.map((pool) =>
        pool.filter((l: any) => {
          if (seenGlobal.has(l.id)) return false;
          seenGlobal.add(l.id);
          return true;
        })
      );

      const sampled: any[] = weightedSample(
        dedupedPools,
        pairs.map((p) => p.weight),
        totalCount
      );

      sampled.sort((a, b) => a.departure_date_start.localeCompare(b.departure_date_start));
      const top: any[] = sampled;

      // Hydrate aircraft_type_id + images
      const ids = top.map((l) => l.id);
      if (ids.length > 0) {
        const { data: legRows } = await (externalSupabase as any)
          .from("empty_legs")
          .select("id, aircraft_type_id")
          .in("id", ids);
        if (legRows) {
          const typeIdMap = new Map((legRows as any[]).map((r: any) => [r.id, r.aircraft_type_id]));
          for (const leg of top) {
            leg.aircraft_type_id = typeIdMap.get(leg.id) ?? null;
          }
        }
        const typeIds = [...new Set(top.map((l) => l.aircraft_type_id).filter(Boolean))] as string[];
        if (typeIds.length > 0) {
          const { data: imgRows } = await (externalSupabase as any)
            .from("aircraft_type_images")
            .select("aircraft_type_id, exterior_image_path, interior_image_path")
            .in("aircraft_type_id", typeIds);
          if (imgRows) {
            const imgMap = new Map((imgRows as any[]).map((r: any) => [r.aircraft_type_id, r]));
            for (const leg of top) {
              const img = imgMap.get(leg.aircraft_type_id);
              leg.exterior_image_path = img?.exterior_image_path ?? null;
              leg.interior_image_path = img?.interior_image_path ?? null;
            }
          }
        }
      }

      return top;
    },
    staleTime: 5 * 60 * 1000,
  });
}


export function UpcomingEmptyLegs() {
  const { data: legs, isLoading, error } = useCorridorEmptyLegs();
  const [leadContext, setLeadContext] = useState<LeadCaptureContext | null>(null);
  const [leadOpen, setLeadOpen] = useState(false);

  const icaos = (legs || []).flatMap((l) => [l.departure_airport_icao, l.arrival_airport_icao].filter(Boolean) as string[]);
  const { data: airportsMap, isLoading: isLoadingAirports } = useAirportsByIcaos(icaos);

  const typeIds = (legs || []).map((l) => l.aircraft_type_id).filter(Boolean) as string[];
  const { data: aircraftTypesMap } = useAircraftTypesByIds(typeIds);

  function getLocationLabel(
  icao: string | null,
  locationType: string | null,
  corridor: string | null,
  locationRaw: string | null)
  : string {
    if (locationType === "airport" && icao) {
      const airport = airportsMap?.[icao];
      if (airport) return formatAirportShort(airport);
      return icao;
    }
    if (locationRaw) return locationRaw;
    if (corridor) return titleCase(corridor);
    if (icao) {
      const airport = airportsMap?.[icao];
      if (airport) return formatAirportShort(airport);
      return icao;
    }
    return "Unknown";
  }

  function handleRequestAvailability(leg: any) {
    const originLabel = getLocationLabel(leg.departure_airport_icao, leg.departure_location_type, leg.departure_corridor, leg.departure_location_raw);
    const destLabel = getLocationLabel(leg.arrival_airport_icao, leg.arrival_location_type, leg.arrival_corridor, leg.arrival_location_raw);

    setLeadContext({
      requestType: "leg_inquiry",
      originIcao: leg.departure_airport_icao || "",
      destinationIcao: leg.arrival_airport_icao || "",
      originLabel,
      destinationLabel: destLabel,
      travelStartDate: leg.departure_date_start,
      travelEndDate: leg.departure_date_end,
      
      emptyLegId: leg.id
    });
    setLeadOpen(true);
  }

  return (
    <div className="mb-6 space-y-3">
      <h3 className="text-center text-primary text-xl font-serif font-bold" style={{ color: "#b7a369" }}>Featured Upcoming Empty Legs

      </h3>

      {isLoading &&
      <div className="flex items-center justify-center gap-2 py-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>Loading upcoming empty legs…</span>
        </div>
      }

      {error &&
      <p className="text-sm text-destructive text-center py-4">
          Unable to load upcoming empty legs.
        </p>
      }

      {!isLoading && !error && legs && legs.length === 0 &&
      <p className="text-sm text-muted-foreground text-center py-4">
          No upcoming empty legs on this route.
        </p>
      }

      {!isLoading && !error && legs && legs.length > 0 &&
      <div className="space-y-2">
          {legs.map((leg) => {
          const aircraftType = leg.aircraft_type_id && aircraftTypesMap?.[leg.aircraft_type_id];
          const aircraftLabel = aircraftType ?
          `${aircraftType.manufacturer || ""} ${aircraftType.model || ""}`.trim() :
          leg.aircraft_model || "Aircraft TBD";
          const exteriorPath = aircraftType?.exterior_image_path ?? (leg as any).exterior_image_path ?? null;
          const interiorPath = aircraftType?.interior_image_path ?? (leg as any).interior_image_path ?? null;
          const category = formatCategory(leg.aircraft_category);
          const seatRange = getCategorySeatRange(leg.aircraft_category);

          return (
            <div
              key={leg.id}
              className="rounded-lg border border-border bg-card p-4">

                {/* Desktop */}
                <div className="hidden sm:flex gap-3 items-center">
                  <AircraftThumbnail
                    path={exteriorPath}
                    interiorPath={interiorPath}
                    className="w-[160px] h-[90px] shrink-0"
                  />
                  <div className="flex flex-col gap-2 flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-sm">
                      <Plane className="h-4 w-4 text-foreground/40 shrink-0" />
                      <span className="font-semibold text-foreground">
                        {formatLocationDisplay(leg.departure_airport_icao, leg.departure_location_type, leg.departure_corridor, leg.departure_location_raw, airportsMap || {}, isLoadingAirports)}
                      </span>
                      <span className="text-foreground/40">→</span>
                      <span className="font-semibold text-foreground">
                        {formatLocationDisplay(leg.arrival_airport_icao, leg.arrival_location_type, leg.arrival_corridor, leg.arrival_location_raw, airportsMap || {}, isLoadingAirports)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-5 text-sm">
                        <div className="flex items-center gap-1.5 text-foreground/70">
                          <Calendar className="h-3.5 w-3.5 shrink-0" />
                          <span>{formatDateRange(leg.departure_date_start, leg.departure_date_end)}</span>
                        </div>
                        <span className="text-foreground/70">{aircraftLabel}</span>
                        {category && <span className="text-muted-foreground">{category}</span>}
                        {seatRange && <span className="text-muted-foreground text-xs">{seatRange}</span>}
                      </div>
                      <Button
                        size="sm"
                        className="shrink-0 text-xs border-none"
                        style={{ backgroundColor: "#b7a369", color: "#fff" }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#a08f55"}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#b7a369"}
                        onClick={() => handleRequestAvailability(leg)}>
                        Request availability
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Mobile */}
                <div className="sm:hidden flex flex-col gap-2">
                  <AircraftThumbnail
                    path={exteriorPath}
                    interiorPath={interiorPath}
                    className="w-full aspect-video"
                  />
                  <div className="flex items-center gap-2 text-sm">
                    <Plane className="h-3.5 w-3.5 text-foreground/40 shrink-0" />
                    <span className="font-semibold text-foreground">
                      {formatLocationDisplay(leg.departure_airport_icao, leg.departure_location_type, leg.departure_corridor, leg.departure_location_raw, airportsMap || {}, isLoadingAirports)}
                    </span>
                    <span className="text-foreground/40">→</span>
                    <span className="font-semibold text-foreground">
                      {formatLocationDisplay(leg.arrival_airport_icao, leg.arrival_location_type, leg.arrival_corridor, leg.arrival_location_raw, airportsMap || {}, isLoadingAirports)}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{formatDateRange(leg.departure_date_start, leg.departure_date_end)}</span>
                    </div>
                    <span className="text-foreground/70">{aircraftLabel}</span>
                  </div>
                  <div className="flex justify-end mt-1">
                    <Button
                      size="sm"
                      className="text-xs border-none"
                      style={{ backgroundColor: "#b7a369", color: "#fff" }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#a08f55"}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#b7a369"}
                      onClick={() => handleRequestAvailability(leg)}>
                      Request availability
                    </Button>
                  </div>
                </div>
              </div>);

        })}
        </div>
      }

      <LeadCaptureDialog
        open={leadOpen}
        onOpenChange={setLeadOpen}
        context={leadContext} />

    </div>);

}